﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pizzeria_2ITC
{
    internal class Ingredience
    {
        public string nazev { get; }
        public int mnozstvi { get; set; }
        public static List<string> ingredience = new List<string> {"raj. protlak",
        "eidam", "žampiony", "šunka", "oregáno", "bazalka", "mozzarela", "ananas",
        "gouda", "mouka", "voda", "sůl", "droždí", "papír"};
        DateTime trvanlivost;

        public Ingredience(string nazev, int mnozstvi) {
            this.nazev = nazev;
            this.mnozstvi = mnozstvi;
            trvanlivost = new DateTime();
        }

    }
}
