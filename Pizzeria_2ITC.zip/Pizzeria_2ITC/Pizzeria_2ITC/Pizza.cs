﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pizzeria_2ITC
{
    internal class Pizza
    {

        public virtual void VytvorPizzu() { 
            //Virtuální metoda pro vytvoření pizzy
        }
    }
}
