﻿using Pizzeria_2ITC;

class Program {
    static void Main(string[] args) {
        Skladiste sklad = new Skladiste();
        sklad.VypisSuroviny();
    }
}