﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pizzeria_2ITC
{
    internal class SunkovaPizza : Pizza
    {
        public override void VytvorPizzu()
        {
            base.VytvorPizzu();
        }
    }
}
