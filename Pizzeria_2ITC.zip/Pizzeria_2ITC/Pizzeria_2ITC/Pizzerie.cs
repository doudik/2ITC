﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pizzeria_2ITC
{
    internal class Pizzerie : Skladiste
    {
        string nazev;
        int pocetStolu, kapacita, kapacitaPece, pizzyVPeci;
        Random rnd = new Random();
        //List<Zamestnanci> zamestnanci = new List<Zamestnanci>();
        
        public Pizzerie(string nazev)
        {
            this.nazev = nazev;
            pocetStolu = rnd.Next(4, 12);
            kapacita = pocetStolu * 4;
            kapacitaPece = 3;
            pizzyVPeci = 0;
        }
        void VyndejPizzu() {
            
        } //TODO
        void ZandejPizzu(Pizza pizza) {
            if (pocetTesta > 0) { 
                //Zandej pizzu do pece:)
            }
        } //TODO

        void VytvorTesto() {
            int needSul = 20;
            int needDrozdi = 20;
            int needVoda = 200;
            int needMouka = 500;
            if (dostupneSuroviny[VratIndexSuroviny("sůl")].mnozstvi >= needSul &&
                dostupneSuroviny[VratIndexSuroviny("droždí")].mnozstvi >= needDrozdi &&
                dostupneSuroviny[VratIndexSuroviny("voda")].mnozstvi >= needVoda &&
                dostupneSuroviny[VratIndexSuroviny("mouka")].mnozstvi >= needMouka) {
                Console.WriteLine("Vytvořil jsi těsto na pizzu!");
                pocetTesta++;
                dostupneSuroviny[VratIndexSuroviny("sůl")].mnozstvi -= needSul;
                dostupneSuroviny[VratIndexSuroviny("droždí")].mnozstvi -= needDrozdi;
                dostupneSuroviny[VratIndexSuroviny("voda")].mnozstvi -= needVoda;
                dostupneSuroviny[VratIndexSuroviny("mouka")].mnozstvi -= needMouka;
            }
            else {
                Console.WriteLine("Nemáš suroviny, zjisti které (:");
            }
        } 
        void VytvorKrabici()
        {
            if (dostupneSuroviny[VratIndexSuroviny("papír")].mnozstvi > 75)
            {
                Console.WriteLine("Vytvořil jsi krabici");
                pocetKrabic++;
                dostupneSuroviny[VratIndexSuroviny("papír")].mnozstvi -= 75;
            }
            else
            {
                Console.WriteLine("Nemáš dostatek papíru pro vytvoření krabice!");
            }
        }
        int VratIndexSuroviny(string surovina)
        {
            //metoda pro vrácení indexu hledané suroviny
            for (int i = 0; i < dostupneSuroviny.Count; i++)
            {
                if (dostupneSuroviny[i].nazev == surovina)
                {
                    return i;
                }
            }
            return -1;
        }


    }
}
