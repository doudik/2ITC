﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pizzeria_2ITC
{
    internal class Skladiste
    {
        protected static List<Ingredience> dostupneSuroviny = new List<Ingredience>();
        public int pocetTesta { get; protected set; }
        public int pocetKrabic { get; protected set; }

        public Skladiste()
        {
            pocetTesta = 0;
            pocetKrabic = 0;
            VytvorSuroviny();
        }
        void VytvorSuroviny() {
            Random rnd = new Random();
            for (int i = 0; i < Ingredience.ingredience.Count; i++)
            {
                dostupneSuroviny.Add(new Ingredience(Ingredience.ingredience[i], rnd.Next(500, 10000)));
            }
        }
        public void VypisSuroviny()
        {
            foreach (var item in dostupneSuroviny)
            {
                Console.WriteLine("{0} - {1}g/ml \n", item.nazev, item.mnozstvi);
            }
        }
        }
}
