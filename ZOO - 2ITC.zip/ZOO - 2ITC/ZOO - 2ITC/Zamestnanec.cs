﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace ZOO___2ITC
{
    internal class Zamestnanec
    {
        //[Zaměstnanci]
        //jmeno
        //            Male/female
        //            moznostPovyseni
        //            výběh, o který se stará
        string jmeno;
        bool male_female;
        bool moznostPovyseni;
        List<Vybeh> vybehyOKtereSeStara;
        public Pozice pozice { get; private set; }
        public Zamestnanec(string jmeno, bool male_female, bool moznostPovyseni = false, Pozice pozice = null)
        {
            this.jmeno = jmeno;
            this.male_female = male_female;
            this.moznostPovyseni = moznostPovyseni;
            this.pozice = pozice;
        }
        void ZmenaPozice(Pozice pozice) {
            if (this.pozice != pozice && this.pozice.vedeni)
            {
                this.pozice = pozice; 
            }
            else { 
                // nemůžeš si změnit pozici 
            }
        }
        public void PriradVybeh(Vybeh vybeh) {
            if (vybehyOKtereSeStara.Contains(vybeh))
            {
                //napise ze uz se o ne stara
            }
            else
            {
                vybehyOKtereSeStara.Add(vybeh);
            }
        }

        public void OdeberVybeh(Vybeh vybeh) {
            if (vybehyOKtereSeStara.Contains(vybeh))
            {
                vybehyOKtereSeStara.Remove(vybeh);
            }
            else
            {
                //vypise : o tento vybeh se ani nestaral
            }
        }
    }

}
