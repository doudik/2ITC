﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace ZOO___2ITC
{
    internal class Masinka
    {
        //[Mašinka]
        //Trasa zastávek
        int kapacitaLidi; //domča has point �� 
        //list lidi co jsou v masince?
        int aktualniObsazenost;
        int cena;
        string[,] obsazenostVozu;
        //nechceme to udelat ze kapacita lidi deleno dvema a budeme mit dverady sedadel 
        //kapacitaLidi/4
    }   // neee to druhy budou 4 vzdycky protoze mame jenom 4 rady sedadel ne?
    //TODO DODĚLAT --> obsazenostVozu
}